interface IEnumUserRole {
    user: string,
    administrator: string
}

export const EnumUserRole: IEnumUserRole = {
    user: 'User',
    administrator: 'Administrator'
}
