import { IPlan } from "../plan/plan";

export interface IPlanGroup{
    id: string,
    
    name: string,
    planCount: number,
}