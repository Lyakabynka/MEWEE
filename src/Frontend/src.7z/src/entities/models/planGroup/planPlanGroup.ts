import { IPlan } from "../plan/plan";

export interface IPlanPlanGroup{
    id: string,
    
    plan: IPlan
}