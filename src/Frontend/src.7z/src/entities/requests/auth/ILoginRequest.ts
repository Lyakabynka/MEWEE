export interface ILoginRequest{
    email: string;
    password: string;
}
