export interface IRegisterRequest {
    username: string;
    email: string;
    password: string;
}