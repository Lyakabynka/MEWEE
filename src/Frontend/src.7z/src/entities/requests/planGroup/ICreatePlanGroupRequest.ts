export interface ICreatePlanGroupRequest {
    name: string,
}