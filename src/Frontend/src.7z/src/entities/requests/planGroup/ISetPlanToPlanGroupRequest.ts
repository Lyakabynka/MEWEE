export interface ISetPlanToPlanGroupRequestModel {
    index: number,
    planId: string
}