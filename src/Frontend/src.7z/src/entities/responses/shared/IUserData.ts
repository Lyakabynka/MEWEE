export interface IUserData{
    id: string,
    username: string,
    email: string,
    role: string,
    isEmailConfirmed: boolean,
    platform: string
}