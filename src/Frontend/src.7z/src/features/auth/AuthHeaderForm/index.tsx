
import './index.css'

export function AuthHeaderForm() {

    

    return (
        <div className='header-content'>
            <div></div>
        </div>
    );
}
